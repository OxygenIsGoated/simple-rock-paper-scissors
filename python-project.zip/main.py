import random
import time
winvariable = False
ChosenRock = False
ChosenPaper = False
ChosenScissors = False
#rockpaperscissorsnuke

text = input().lower()
if text == "rock".lower():
  ChosenRock = True
  print("rock... paper.. scissors.. ROCK!!!!!")
if text == "paper".lower():
  ChosenPaper = True
  print("rock.. paper.. scissors.. PAPER!!!!!")
if text == "scissors".lower():
  ChosenScissors = True
  print("rock.. paper.. scissors.. SCISSORS!!!!!!")


randint1 = random.randint(1, 4)
if randint1 == 1:
  print("the computer chose ROCK!!!!")
  if ChosenPaper == True:
    print("human won..... YAY")
    winvariable = True
  elif ChosenRock == True:
    print("DRAW.")
  else:
    print("you lost LOSER")
if randint1 == 2:
  print("the computer chose PAPER!!!!")
  if ChosenScissors == True:
    print("human won YAY!")
    winvariable = True
  elif ChosenPaper == True:
    print("its a DRAW..")
  else:
    print("you lost LOSER")
if randint1 == 3:
  print("the computer chose SCISSORS!!!!")
  if ChosenRock == True:
    print("HUMAN WON!!!!!!!")
    winvariable = True
  elif ChosenScissors == True:
    print("DRAW..")
  else:
    print("you lost loser..")
if randint1 == 4:
  print("the computer chose NUKE! THE COMPUTER WINS IMMEDIATELY!")

  if winvariable == True:
    print("AI: aw man you won..........")

